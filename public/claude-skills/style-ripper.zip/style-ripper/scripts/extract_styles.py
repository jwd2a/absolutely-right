#!/usr/bin/env python3
"""
Extract brand and styling guidelines from a website.
Analyzes HTML, CSS, and visual elements to generate comprehensive brand documentation.
"""

import sys
import re
import json
from urllib.parse import urljoin, urlparse
from collections import Counter
from bs4 import BeautifulSoup


def extract_colors_from_css(css_text):
    """Extract all color values from CSS text."""
    colors = set()
    
    # Hex colors
    hex_colors = re.findall(r'#(?:[0-9a-fA-F]{3}){1,2}\b', css_text)
    colors.update(hex_colors)
    
    # RGB/RGBA colors
    rgb_colors = re.findall(r'rgba?\([^)]+\)', css_text)
    colors.update(rgb_colors)
    
    # HSL/HSLA colors
    hsl_colors = re.findall(r'hsla?\([^)]+\)', css_text)
    colors.update(hsl_colors)
    
    return colors


def extract_fonts_from_css(css_text):
    """Extract font families and font URLs from CSS."""
    fonts = set()
    font_urls = []
    
    # Extract font-family declarations
    font_family_matches = re.findall(r'font-family:\s*([^;]+);', css_text, re.IGNORECASE)
    for match in font_family_matches:
        # Clean up the font family string
        font_families = [f.strip().strip('"').strip("'") for f in match.split(',')]
        fonts.update(font_families)
    
    # Extract @font-face URLs
    font_face_matches = re.findall(r'@font-face\s*{([^}]+)}', css_text, re.DOTALL)
    for font_face in font_face_matches:
        url_matches = re.findall(r'url\([\'"]?([^\'")]+)[\'"]?\)', font_face)
        font_urls.extend(url_matches)
    
    return fonts, font_urls


def analyze_html_structure(soup, base_url):
    """Analyze HTML structure for brand elements."""
    data = {
        'title': '',
        'description': '',
        'logos': [],
        'favicon': None,
        'og_image': None,
        'stylesheets': [],
        'inline_styles': '',
        'colors': set(),
        'fonts': set(),
        'font_urls': [],
        'headings': {},
        'buttons': [],
        'links': []
    }
    
    # Basic metadata
    if soup.title:
        data['title'] = soup.title.string
    
    meta_desc = soup.find('meta', attrs={'name': 'description'})
    if meta_desc and meta_desc.get('content'):
        data['description'] = meta_desc['content']
    
    # Open Graph image
    og_image = soup.find('meta', attrs={'property': 'og:image'})
    if og_image and og_image.get('content'):
        data['og_image'] = urljoin(base_url, og_image['content'])
    
    # Favicon
    favicon = soup.find('link', rel=lambda x: x and 'icon' in x.lower())
    if favicon and favicon.get('href'):
        data['favicon'] = urljoin(base_url, favicon['href'])
    
    # Find potential logos
    for img in soup.find_all('img'):
        alt = img.get('alt', '').lower()
        src = img.get('src', '')
        classes = ' '.join(img.get('class', [])).lower()
        
        if any(term in alt or term in classes or term in src.lower() 
               for term in ['logo', 'brand']):
            data['logos'].append(urljoin(base_url, src))
    
    # Extract stylesheets
    for link in soup.find_all('link', rel='stylesheet'):
        if link.get('href'):
            data['stylesheets'].append(urljoin(base_url, link['href']))
    
    # Collect inline styles
    for style_tag in soup.find_all('style'):
        if style_tag.string:
            data['inline_styles'] += style_tag.string + '\n'
    
    # Collect style attributes
    for tag in soup.find_all(style=True):
        data['inline_styles'] += tag['style'] + '\n'
    
    # Analyze headings
    for level in range(1, 7):
        headings = soup.find_all(f'h{level}')
        if headings:
            data['headings'][f'h{level}'] = len(headings)
    
    # Sample button styles
    buttons = soup.find_all(['button', 'input'])
    for btn in buttons[:5]:  # Limit to first 5
        btn_data = {
            'text': btn.get_text(strip=True) if btn.name == 'button' else btn.get('value', ''),
            'classes': ' '.join(btn.get('class', [])),
            'style': btn.get('style', '')
        }
        data['buttons'].append(btn_data)
    
    # Sample link styles
    links = soup.find_all('a', href=True)
    for link in links[:10]:  # Limit to first 10
        link_data = {
            'text': link.get_text(strip=True),
            'classes': ' '.join(link.get('class', [])),
            'href': link['href']
        }
        data['links'].append(link_data)
    
    return data


def generate_markdown_report(data, url):
    """Generate a markdown report of brand guidelines."""
    
    report = f"""# Brand & Style Guidelines

**Extracted from:** {url}

## Overview

**Site Title:** {data['title'] or 'N/A'}
**Description:** {data['description'] or 'N/A'}

---

## Brand Assets

### Logo Files
"""
    
    if data['logos']:
        for idx, logo in enumerate(data['logos'], 1):
            report += f"{idx}. [{logo}]({logo})\n"
    else:
        report += "*No logos detected*\n"
    
    report += "\n### Favicon\n"
    if data['favicon']:
        report += f"[{data['favicon']}]({data['favicon']})\n"
    else:
        report += "*No favicon detected*\n"
    
    report += "\n### Open Graph Image\n"
    if data['og_image']:
        report += f"[{data['og_image']}]({data['og_image']})\n"
    else:
        report += "*No OG image detected*\n"
    
    report += "\n---\n\n## Color Palette\n\n"
    
    if data['colors']:
        # Count color frequency
        color_counter = Counter(data['colors'])
        most_common = color_counter.most_common(20)  # Top 20 colors
        
        for color, count in most_common:
            # Try to display the color if it's a hex
            if color.startswith('#'):
                report += f"- **{color}** (used {count}x)\n"
            else:
                report += f"- `{color}` (used {count}x)\n"
    else:
        report += "*No colors extracted*\n"
    
    report += "\n---\n\n## Typography\n\n### Font Families\n\n"
    
    if data['fonts']:
        # Remove generic fonts and duplicates
        custom_fonts = [f for f in data['fonts'] 
                       if f.lower() not in ['serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui']]
        
        if custom_fonts:
            for font in sorted(set(custom_fonts)):
                report += f"- {font}\n"
        else:
            report += "*Using system fonts only*\n"
    else:
        report += "*No fonts detected*\n"
    
    if data['font_urls']:
        report += "\n### Font Files\n\n"
        for font_url in data['font_urls'][:10]:  # Limit to 10
            report += f"- [{font_url}]({font_url})\n"
    
    report += "\n---\n\n## Heading Structure\n\n"
    
    if data['headings']:
        for tag, count in sorted(data['headings'].items()):
            report += f"- **{tag.upper()}**: {count} instances\n"
    else:
        report += "*No headings found*\n"
    
    report += "\n---\n\n## Component Styles\n\n### Button Examples\n\n"
    
    if data['buttons']:
        for idx, btn in enumerate(data['buttons'], 1):
            report += f"**Button {idx}:**\n"
            if btn['text']:
                report += f"- Text: \"{btn['text']}\"\n"
            if btn['classes']:
                report += f"- Classes: `{btn['classes']}`\n"
            if btn['style']:
                report += f"- Inline styles: `{btn['style']}`\n"
            report += "\n"
    else:
        report += "*No buttons found*\n"
    
    report += "\n### Link Examples\n\n"
    
    if data['links']:
        for idx, link in enumerate(data['links'][:5], 1):  # Show first 5
            report += f"**Link {idx}:**\n"
            if link['text']:
                report += f"- Text: \"{link['text']}\"\n"
            if link['classes']:
                report += f"- Classes: `{link['classes']}`\n"
            report += "\n"
    else:
        report += "*No links found*\n"
    
    report += "\n---\n\n## Stylesheets\n\n"
    
    if data['stylesheets']:
        report += "External CSS files used:\n\n"
        for css in data['stylesheets']:
            report += f"- [{css}]({css})\n"
    else:
        report += "*No external stylesheets detected*\n"
    
    report += "\n---\n\n## Notes\n\n"
    report += "- This analysis is based on the HTML structure and inline styles\n"
    report += "- For complete styling information, examine the linked CSS files\n"
    report += "- Colors shown are the most frequently used across the site\n"
    report += "- Some styling may be applied dynamically via JavaScript\n"
    
    return report


def main(html_content, url):
    """Main function to extract style guidelines from HTML content."""
    
    soup = BeautifulSoup(html_content, 'html.parser')
    base_url = url
    
    # Analyze HTML structure
    data = analyze_html_structure(soup, base_url)
    
    # Extract colors and fonts from inline styles
    if data['inline_styles']:
        colors = extract_colors_from_css(data['inline_styles'])
        data['colors'].update(colors)
        
        fonts, font_urls = extract_fonts_from_css(data['inline_styles'])
        data['fonts'].update(fonts)
        data['font_urls'].extend(font_urls)
    
    # Convert sets to lists for JSON serialization
    data['colors'] = list(data['colors'])
    data['fonts'] = list(data['fonts'])
    
    # Generate markdown report
    report = generate_markdown_report(data, url)
    
    return report


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python extract_styles.py <html_file> <url>")
        print("   or: provide HTML content via stdin with URL as first arg")
        sys.exit(1)
    
    if len(sys.argv) == 2:
        # Read from stdin
        html_content = sys.stdin.read()
        url = sys.argv[1]
    else:
        # Read from file
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            html_content = f.read()
        url = sys.argv[2]
    
    report = main(html_content, url)
    print(report)
