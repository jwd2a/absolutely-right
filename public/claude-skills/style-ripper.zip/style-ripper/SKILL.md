---
name: style-ripper
description: Extract comprehensive brand and styling guidelines from websites. Use this skill when users provide a URL and want to capture brand elements including colors, fonts, logos, typography, component styles, and design patterns. Generates markdown documentation with hex codes, asset links, and reusable style information.
---

# Style Ripper

Extract comprehensive brand and styling guidelines from any website by analyzing HTML structure, CSS, and visual elements.

## Overview

This skill analyzes a website's HTML and CSS to generate a complete brand guidelines document in markdown format. It captures:

- Color palettes (hex codes, RGB, HSL)
- Typography (font families and font files)
- Logo files and brand assets
- Favicon and Open Graph images
- Heading structure and hierarchy
- Button and link styles
- External stylesheet references

## Workflow

1. Fetch the website using `web_fetch` tool
2. Save HTML content to a temporary file
3. Run `extract_styles.py` script to analyze the content
4. Save the generated markdown report to `/mnt/user-data/outputs/`
5. Share the brand guidelines document with the user

## Usage

When a user provides a URL and requests brand/style information:

```bash
# Step 1: Fetch the website (this happens via web_fetch tool call)

# Step 2: Save HTML to temporary file
cat > /tmp/website.html << 'HTMLEOF'
[HTML content from web_fetch]
HTMLEOF

# Step 3: Run the extraction script
python /home/claude/style-ripper/scripts/extract_styles.py /tmp/website.html "https://example.com" > /mnt/user-data/outputs/brand-guidelines.md

# Step 4: Share the output file with user
```

Alternative: Pipe HTML directly to the script:

```bash
echo "[HTML content]" | python /home/claude/style-ripper/scripts/extract_styles.py "https://example.com" > /mnt/user-data/outputs/brand-guidelines.md
```

## Script Details

### `scripts/extract_styles.py`

Analyzes HTML and CSS to extract brand guidelines.

**Dependencies:** beautifulsoup4 (install with `pip install beautifulsoup4 --break-system-packages`)

**Input:** 
- HTML file path + URL, or
- HTML content via stdin + URL as argument

**Output:** Markdown-formatted brand guidelines document

**Features:**
- Extracts all color values (hex, RGB, RGBA, HSL, HSLA) with usage frequency
- Identifies font families and font file URLs
- Locates logo images and brand assets
- Captures favicon and Open Graph images
- Analyzes heading structure
- Samples button and link component styles
- Lists external stylesheet references

## Output Format

The generated markdown document includes:

- **Brand Assets**: Logos, favicon, OG image with direct links
- **Color Palette**: All colors found, ranked by frequency of use
- **Typography**: Font families and font file URLs
- **Heading Structure**: H1-H6 usage statistics
- **Component Styles**: Sample buttons and links with classes and inline styles
- **Stylesheets**: Links to external CSS files for deeper analysis

## Notes

- Install beautifulsoup4 before first use: `pip install beautifulsoup4 --break-system-packages`
- The script analyzes static HTML/CSS; some styles may be applied dynamically via JavaScript
- Color frequency helps identify primary brand colors vs. one-off usage
- External CSS files are linked but not automatically analyzed (user can fetch them separately if needed)
- Generic system fonts (serif, sans-serif, etc.) are filtered from the font list
